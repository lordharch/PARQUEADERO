package com.parqueo.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParqueaderoApplicationTests {

	@Test
	void contextLoads() {
	}

}
